#define OLC_PGE_APPLICATION
#include "olcPixelGameEngine.h"
