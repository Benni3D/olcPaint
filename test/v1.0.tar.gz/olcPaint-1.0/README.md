# olcPaint
This is a small paint program based on the olcPixelGameEngine.<br>
Compile with: <code>./compile.sh</code><br>

# Keys
Arrow Keys: Move around (+ ALT: slower, + SHIFT: faster)<br>
F2: Invert Arrow Keys<br>
Mouse Wheel: Scroll Up/Down<br>
SHIFT + Mouse Wheel: Scroll Left/Right<br>
CTRL + Mouse Wheel: Zoom In/Out (or +/-)<br>
CTRL + S: Save Image<br>

